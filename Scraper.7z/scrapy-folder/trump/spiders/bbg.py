import scrapy
import numpy as np
import urllib
import time
import pkgutil
import io



class QuotesSpider(scrapy.Spider):
    name = "bbg"

    def start_requests(self):
        #fobj = BytesIO(pkgutil.get_data(__name__, 'hex-gleg-ord3.npz'))
        #refm = np.load(fobj)
        data =  io.BytesIO(pkgutil.get_data("trump", "resources/slice_11.npy"))
        urls = np.load(data)
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)
            time.sleep(5)

    def parse(self, response):

        """logic to handle the response from the URL"""

        #understanding the output
        print(type(response))
        print(response.url)
        
        #naming the output file
        date = response.url.split("/")[-2] #article date
        article_name =response.url.split("/")[-1] #article name in url
        filename = 'bbg-{}-{}.html'.format(date, article_name)
        
        #write the response to the output file
        with open(filename, 'wb') as f:
            f.write(response.body)
        self.log('Saved file %s' % filename)#log saving of file

        #handling logic:
        pass