# Automatically created by: shub deploy

from setuptools import setup, find_packages

setup(
    name         = 'trump',
    version      = '1.7',
    packages     = find_packages(),
    entry_points = {'scrapy': ['settings = trump.settings']},
	package_data={
        'trump': ['resources/slice_11.npy']
    },
	zip_safe=False,
)
